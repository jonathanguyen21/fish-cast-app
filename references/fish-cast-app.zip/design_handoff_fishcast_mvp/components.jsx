// components.jsx — FishCast core widgets

// ── ScoreRing — circular progress ring around a big number ─────────────
function ScoreRing({ score, size = 220, stroke = 10, t }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = (score / 100) * c;
  const col = scoreColor(score, t);
  const gid = `ring-${col.replace('#','')}-${size}`;
  return (
    <div style={{ width: size, height: size, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <svg width={size} height={size} style={{ position: 'absolute', inset: 0, transform: 'rotate(-90deg)' }}>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={col} stopOpacity="0.55" />
            <stop offset="100%" stopColor={col} stopOpacity="1" />
          </linearGradient>
        </defs>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={stroke} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={`url(#${gid})`} strokeWidth={stroke}
          strokeLinecap="round" strokeDasharray={`${dash} ${c}`} />
        {Array.from({length: 60}).map((_, i) => {
          if (i % 5 !== 0) return null;
          const a = (i / 60) * 2 * Math.PI;
          const x1 = size/2 + Math.cos(a) * (r - stroke/2 - 6);
          const y1 = size/2 + Math.sin(a) * (r - stroke/2 - 6);
          const x2 = size/2 + Math.cos(a) * (r - stroke/2 - 11);
          const y2 = size/2 + Math.sin(a) * (r - stroke/2 - 11);
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="rgba(255,255,255,0.18)" strokeWidth="1" />;
        })}
      </svg>
      <div style={{ textAlign: 'center', position: 'relative' }}>
        <div style={{ fontSize: size * 0.42, fontWeight: 700, color: col, lineHeight: 1, letterSpacing: -2, ...TAB,
          fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>{score}</div>
        <div style={{ fontSize: 9, color: t.text3, letterSpacing: 2.5, marginTop: 6, textTransform: 'uppercase', fontWeight: 600 }}>
          fishing score
        </div>
      </div>
    </div>
  );
}

// ── ScoreNumber — big glyph, no ring ───────────────────────────────────
function ScoreNumber({ score, t, size = 140 }) {
  const col = scoreColor(score, t);
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, justifyContent: 'center' }}>
      <div style={{ fontSize: size, fontWeight: 700, color: col, lineHeight: 0.85, letterSpacing: -5, ...TAB,
        fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace',
        textShadow: `0 0 30px ${col}33`,
      }}>{score}</div>
      <div style={{ fontSize: size * 0.18, color: t.text3, fontWeight: 600, ...TAB, fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>/100</div>
    </div>
  );
}

// ── TideCurve — SVG smooth curve for 24 hourly heights ─────────────────
function TideCurve({ data, currentHour, t, height = 110, showLabels = true, events = [] }) {
  const W = 320, H = height;
  const pad = { l: 8, r: 8, t: 16, b: showLabels ? 20 : 6 };
  const max = Math.max(...data) + 0.5;
  const min = Math.min(...data) - 0.3;
  const xFor = (i) => pad.l + (i / (data.length - 1)) * (W - pad.l - pad.r);
  const yFor = (v) => pad.t + (1 - (v - min) / (max - min)) * (H - pad.t - pad.b);
  let d = `M ${xFor(0)} ${yFor(data[0])}`;
  for (let i = 0; i < data.length - 1; i++) {
    const x0 = xFor(i), y0 = yFor(data[i]);
    const x1 = xFor(i+1), y1 = yFor(data[i+1]);
    const mx = (x0 + x1) / 2;
    d += ` C ${mx} ${y0}, ${mx} ${y1}, ${x1} ${y1}`;
  }
  const fill = d + ` L ${xFor(data.length-1)} ${H-pad.b} L ${xFor(0)} ${H-pad.b} Z`;
  const cx = xFor(currentHour);
  const cy = yFor(data[currentHour]);
  const gid = `tideFill-${t.blue.replace('#','')}-${height}`;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} preserveAspectRatio="none" style={{ display: 'block' }}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={t.blue} stopOpacity="0.4" />
          <stop offset="100%" stopColor={t.blue} stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0.33, 0.66].map(p => (
        <line key={p} x1={pad.l} x2={W-pad.r} y1={pad.t + p*(H-pad.t-pad.b)} y2={pad.t + p*(H-pad.t-pad.b)}
          stroke="rgba(255,255,255,0.05)" strokeDasharray="2 4" />
      ))}
      <path d={fill} fill={`url(#${gid})`} />
      <path d={d} fill="none" stroke={t.blue} strokeWidth="1.6" strokeLinecap="round" />
      <line x1={cx} x2={cx} y1={pad.t} y2={H-pad.b} stroke={t.accent} strokeWidth="1" strokeDasharray="3 3" opacity="0.7" />
      <circle cx={cx} cy={cy} r="8" fill={t.accent} opacity="0.2" />
      <circle cx={cx} cy={cy} r="3.5" fill={t.accent} />
      {showLabels && events.map((e, i) => {
        const m = e.time.match(/(\d+):(\d+)\s*(AM|PM)/i);
        if (!m) return null;
        let hr = parseInt(m[1]); const isPM = m[3].toUpperCase() === 'PM';
        if (isPM && hr !== 12) hr += 12; if (!isPM && hr === 12) hr = 0;
        if (hr >= data.length) return null;
        const x = xFor(hr); const y = yFor(data[hr]);
        const above = e.type === 'high';
        return (
          <g key={i}>
            <circle cx={x} cy={y} r="2.5" fill={t.text2} />
            <text x={x} y={above ? y - 6 : y + 11} textAnchor="middle" fontSize="8.5" fill={t.text2} style={TAB} fontWeight="600">
              {e.type === 'high' ? 'H' : 'L'} {e.height}'
            </text>
          </g>
        );
      })}
      {showLabels && [0, 6, 12, 18].map((h) => (
        <text key={h} x={xFor(h)} y={H - 5} textAnchor="middle" fontSize="9" fill={t.text3} style={TAB}>
          {h === 0 ? '12A' : h === 12 ? '12P' : h < 12 ? `${h}A` : `${h-12}P`}
        </text>
      ))}
    </svg>
  );
}

// ── ScoreTimeline — vertical bars ─────────────────────────────────────
function ScoreTimeline({ data, t, height = 90, density = 'regular' }) {
  const peak = Math.max(...data.map(d => d.score));
  const peakIdx = data.findIndex(d => d.score === peak);
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height }}>
      {data.map((h, i) => {
        const col = scoreColor(h.score, t);
        const isPeak = i === peakIdx;
        const hgt = Math.max(4, (h.score / 100) * (height - 16));
        return (
          <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
            <div style={{
              width: '100%', height: hgt, borderRadius: 2, position: 'relative',
              background: col, opacity: isPeak ? 1 : 0.7,
              boxShadow: isPeak ? `0 0 10px ${col}88` : 'none',
            }} />
            <div style={{ fontSize: 8, color: isPeak ? t.text : t.text3, ...TAB, fontWeight: isPeak ? 700 : 400 }}>
              {h.hour}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── WindDial — compass with rotated arrow ─────────────────────────────
function WindDial({ wind, t, size = 60 }) {
  const col = wind.speed >= 19 ? t.red : wind.speed >= 13 ? t.amber : t.green;
  return (
    <svg width={size} height={size} viewBox="0 0 72 72">
      <circle cx="36" cy="36" r="32" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      <circle cx="36" cy="36" r="24" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" strokeDasharray="2 3" />
      {['N','E','S','W'].map((c, i) => {
        const a = (i * 90 - 90) * Math.PI / 180;
        const x = 36 + Math.cos(a) * 30;
        const y = 36 + Math.sin(a) * 30 + 3;
        return <text key={c} x={x} y={y} textAnchor="middle" fontSize="8" fill={t.text3} fontWeight="700">{c}</text>;
      })}
      <g transform={`rotate(${wind.direction} 36 36)`}>
        <path d="M36 14 L42 38 L36 33 L30 38 Z" fill={col} />
        <line x1="36" y1="33" x2="36" y2="56" stroke={col} strokeWidth="2" strokeLinecap="round" opacity="0.35" />
      </g>
      <circle cx="36" cy="36" r="2" fill={t.text2} />
    </svg>
  );
}

// ── StatCard — generic data tile with icon, label, value, sub ─────────
function StatCard({ icon, label, value, sub, t, accent }) {
  return (
    <div style={{
      background: t.card, borderRadius: 14, padding: '12px 12px 11px',
      border: `0.5px solid ${t.cardEdge}`,
      display: 'flex', flexDirection: 'column', gap: 4, minHeight: 78,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: t.text3 }}>
        {icon}
        <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase' }}>{label}</div>
      </div>
      <div style={{ fontSize: 22, fontWeight: 700, color: accent || t.text, lineHeight: 1.05, ...TAB,
        fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace', letterSpacing: -0.5 }}>
        {value}
      </div>
      {sub && <div style={{ fontSize: 11, color: t.text2, ...TAB, marginTop: 'auto' }}>{sub}</div>}
    </div>
  );
}

// ── SectionHeader ─────────────────────────────────────────────────────
function SectionHeader({ title, right, t }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '0 4px 8px' }}>
      <div style={{ fontSize: 10, fontWeight: 700, color: t.text3, letterSpacing: 1.5, textTransform: 'uppercase' }}>{title}</div>
      {right && <div style={{ fontSize: 11, color: t.text2 }}>{right}</div>}
    </div>
  );
}

// ── Card wrapper ─────────────────────────────────────────────────────
function Card({ t, children, style = {}, padding = 14 }) {
  return (
    <div style={{
      background: t.card, borderRadius: 18,
      border: `0.5px solid ${t.cardEdge}`,
      padding, ...style,
    }}>{children}</div>
  );
}

// ── MoonGlyph — circle with terminator showing illumination ──────────
function MoonGlyph({ illumination, t, size = 28 }) {
  const r = size / 2 - 1;
  const k = 1 - 2 * illumination / 100; // -1 (full) to 1 (new)
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size/2} cy={size/2} r={r} fill="rgba(255,255,255,0.08)" stroke={t.text3} strokeWidth="0.7" />
      <path d={`M ${size/2} ${size/2-r} A ${r} ${r} 0 0 1 ${size/2} ${size/2+r} A ${r*Math.abs(k)} ${r} 0 0 ${k>0?1:0} ${size/2} ${size/2-r} Z`}
        fill="#FAF3EC" opacity="0.92" />
    </svg>
  );
}

// ── MiniBars — small score bars row (used in spots list) ─────────────
function MiniBars({ data, t, height = 22, width = 70 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 1.5, height, width }}>
      {data.slice(0, 16).map((h, i) => (
        <div key={i} style={{
          flex: 1, height: Math.max(2, (h.score / 100) * height),
          background: scoreColor(h.score, t), opacity: 0.75, borderRadius: 1,
        }} />
      ))}
    </div>
  );
}

// ── SpeciesActivityBar — 12-month activity heatmap ──────────────────
function SpeciesActivityBar({ months, peakMonths, currentMonth, t }) {
  const labels = ['J','F','M','A','M','J','J','A','S','O','N','D'];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <div style={{ display: 'flex', gap: 3 }}>
        {Array.from({length: 12}).map((_, i) => {
          const m = i + 1;
          const isPeak = peakMonths.includes(m);
          const isPresent = months.includes(m);
          const isNow = currentMonth === m;
          const bg = isPeak ? t.green : isPresent ? `${t.green}55` : 'rgba(255,255,255,0.05)';
          return (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
              <div style={{ width: '100%', height: 18, background: bg, borderRadius: 3,
                border: isNow ? `1.5px solid ${t.accent}` : 'none',
                boxSizing: 'border-box',
              }} />
              <div style={{ fontSize: 9, color: isNow ? t.accent : t.text3, fontWeight: isNow ? 700 : 500 }}>{labels[i]}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── TabBar — bottom navigation ───────────────────────────────────────
function TabBar({ t, active, onChange }) {
  const tabs = [
    { id: 'dash', label: 'Today', icon: 'gauge' },
    { id: 'spots', label: 'Spots', icon: 'pin' },
    { id: 'species', label: 'Biting', icon: 'fish' },
    { id: 'settings', label: 'Settings', icon: 'cog' },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0, paddingBottom: 24, paddingTop: 8,
      background: `linear-gradient(180deg, ${t.bg}00 0%, ${t.bg} 50%)`,
      display: 'flex', justifyContent: 'space-around', zIndex: 20,
    }}>
      {tabs.map(tab => {
        const isActive = tab.id === active;
        const c = isActive ? t.accent : t.text3;
        return (
          <button key={tab.id} onClick={() => onChange && onChange(tab.id)}
            style={{ background: 'transparent', border: 0, padding: '4px 10px',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, cursor: 'pointer' }}>
            {Icon[tab.icon](c, 22)}
            <div style={{ fontSize: 10, color: c, fontWeight: isActive ? 700 : 500 }}>{tab.label}</div>
          </button>
        );
      })}
    </div>
  );
}

Object.assign(window, {
  ScoreRing, ScoreNumber, TideCurve, ScoreTimeline, WindDial,
  StatCard, SectionHeader, Card, MoonGlyph, MiniBars,
  SpeciesActivityBar, TabBar,
});
