// theme.jsx — FishCast theme constants + shared SVG icons + helpers
// Maritime Instrument aesthetic: deep navy + sea foam + ocean blue.

const FC_THEMES = {
  midnight: {
    name: 'Midnight (default)',
    bg: '#0B1622',
    bgGrad: 'linear-gradient(180deg, #0B1622 0%, #0E1A2A 60%, #0B1622 100%)',
    surface: '#142233',
    card: '#1A2D42',
    cardEdge: 'rgba(255,255,255,0.06)',
    text: '#F1F5F9',
    text2: '#94A3B8',
    text3: '#64748B',
    accent: '#00C9A7',
    blue: '#3B82F6',
    amber: '#F59E0B',
    red: '#EF4444',
    green: '#10B981',
  },
  dawn: {
    name: 'Dawn (warm)',
    bg: '#1A1410',
    bgGrad: 'linear-gradient(180deg, #1F1812 0%, #2A1A14 50%, #1A1410 100%)',
    surface: '#241A14',
    card: '#2D2018',
    cardEdge: 'rgba(255,200,160,0.07)',
    text: '#FAF3EC',
    text2: '#B8A595',
    text3: '#80705E',
    accent: '#F4A85C',
    blue: '#E07B5C',
    amber: '#F59E0B',
    red: '#EF4444',
    green: '#A8C95A',
  },
  reef: {
    name: 'Reef (teal)',
    bg: '#06181C',
    bgGrad: 'linear-gradient(180deg, #06181C 0%, #082528 60%, #06181C 100%)',
    surface: '#0D2428',
    card: '#123036',
    cardEdge: 'rgba(120,220,200,0.08)',
    text: '#ECFDF5',
    text2: '#86C7B8',
    text3: '#558678',
    accent: '#2DD4BF',
    blue: '#06B6D4',
    amber: '#FBBF24',
    red: '#FB7185',
    green: '#34D399',
  },
};

// score-color helper
function scoreColor(score, t) {
  if (score >= 70) return t.green;
  if (score >= 40) return t.amber;
  return t.red;
}
function scoreLabel(score) {
  if (score >= 85) return 'Drop everything and go';
  if (score >= 70) return 'Great day to fish';
  if (score >= 55) return 'Decent — pick your window';
  if (score >= 40) return 'Tough but possible';
  return 'Stay home';
}

// Tabular numerics
const TAB = { fontVariantNumeric: 'tabular-nums', fontFeatureSettings: '"tnum"' };

// ── Tiny SVG icon set (stroke-based, monoline) ───────────────────────────
const Icon = {
  wind: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 8h11a3 3 0 1 0-3-3" />
      <path d="M3 12h17a3 3 0 1 1-3 3" />
      <path d="M3 16h9" />
    </svg>
  ),
  wave: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 12c2.5-3 4.5-3 7 0s4.5 3 7 0 4.5-3 6 0" />
      <path d="M2 17c2.5-3 4.5-3 7 0s4.5 3 7 0 4.5-3 6 0" />
    </svg>
  ),
  drop: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 3c-3 4-6 7-6 11a6 6 0 0 0 12 0c0-4-3-7-6-11z" />
    </svg>
  ),
  thermo: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 14V4a2 2 0 1 0-4 0v10a4 4 0 1 0 4 0z" />
      <circle cx="12" cy="17" r="2" fill={c} stroke="none" />
    </svg>
  ),
  gauge: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 16a8 8 0 1 1 16 0" />
      <path d="M12 16l4-5" />
    </svg>
  ),
  cloud: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7 18a4 4 0 0 1 .8-7.9A6 6 0 0 1 19 12a3.5 3.5 0 0 1-1 6.9z" />
      <circle cx="16" cy="8" r="2.4" fill={c} stroke="none" opacity="0.5" />
    </svg>
  ),
  moon: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 14a8 8 0 1 1-10-10 6 6 0 0 0 10 10z" />
    </svg>
  ),
  sun: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3.5" />
      <path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4" />
    </svg>
  ),
  pin: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 21s7-7.2 7-12a7 7 0 1 0-14 0c0 4.8 7 12 7 12z" />
      <circle cx="12" cy="9" r="2.5" />
    </svg>
  ),
  fish: (c, s = 18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12c2-4 6-6 10-6 4 0 7 2 8 6-1 4-4 6-8 6-4 0-8-2-10-6z" />
      <path d="M22 12l-4-3v6z" fill={c} stroke="none" />
      <circle cx="9" cy="11" r="0.8" fill={c} stroke="none" />
    </svg>
  ),
  arrow: (deg, c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" style={{ transform: `rotate(${deg}deg)` }} fill="none" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 4v16M12 4l-5 5M12 4l5 5" />
    </svg>
  ),
  trendDown: (c, s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6l9 9 4-4 5 5"/><path d="M21 16v-5"/></svg>
  ),
  trendUp: (c, s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 18l9-9 4 4 5-5"/><path d="M21 8v5"/></svg>
  ),
  search: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
  ),
  plus: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14"/></svg>
  ),
  chevR: (c, s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 6l6 6-6 6"/></svg>
  ),
  chevL: (c, s = 14) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 6l-6 6 6 6"/></svg>
  ),
  bell: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>
  ),
  cog: (c, s = 16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>
  ),
};

Object.assign(window, { FC_THEMES, scoreColor, scoreLabel, TAB, Icon });
