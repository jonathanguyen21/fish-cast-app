# Handoff: FishCast MVP — Comfy Dashboard

## Overview

FishCast is a fishing-conditions app: open it, see your spot, know if you should go. This handoff covers the **5 MVP screens** from the project plan, with the **Comfy / Hero dashboard** chosen as the primary dashboard design (out of 3 explored density variations).

The design tab inside `FishCast Mockups.html` shows only the chosen Comfy variant alongside the four supporting screens. The full source for all three density explorations is preserved in `screens.jsx` for reference (`DashboardComfy`, `DashboardRegular`, `DashboardCompact`) — only `DashboardComfy` needs to be ported.

## About the Design Files

The HTML/JSX files in this bundle are **design references**, not production code. They are React-via-Babel-in-the-browser prototypes that show the intended look, layout, spacing, color, and behavior of each screen.

The task is to **recreate these designs in the FishCast codebase** described in the project plan (Expo + React Native + TypeScript) using its established patterns and libraries — NOT to copy the JSX or DOM as-is. SVG components like the score ring, tide curve, wind dial, and fish glyph translate directly to `react-native-svg`. CSS-in-JS styles map to React Native `StyleSheet`.

If you encounter any inline `Tweaks` panel logic or design-canvas wrappers, ignore them — they are tooling for the design preview only.

## Fidelity

**High-fidelity (hifi).** Every color, spacing value, font weight, border radius, and SVG path is final. Recreate the UI pixel-perfectly using React Native primitives + `react-native-svg`. Where measurements are in CSS pixels, treat them as React Native density-independent units (dp).

## Key Files in This Bundle

| File | What it contains |
|---|---|
| `FishCast Mockups.html` | Entry point that mounts the React app inside a design canvas |
| `theme.jsx` | `FC_THEMES` color tokens (Midnight is canonical), `scoreColor`/`scoreLabel` helpers, monoline SVG icon set |
| `data.jsx` | Mock conditions, spots, species — matches the plan's "Static Data" section |
| `components.jsx` | Reusable widgets: `ScoreRing`, `TideCurve`, `ScoreTimeline`, `WindDial`, `StatCard`, `MoonGlyph`, `MiniBars`, `SpeciesActivityBar`, `TabBar` |
| `screens.jsx` | The 5 screens. Port only `DashboardComfy`, `SpotsList`, `AddSpot`, `SpeciesDetail`, `Settings` |
| `fishcast-project-plan-v2.md` | The full original product plan (unchanged) |

`ios-frame.jsx`, `design-canvas.jsx`, `tweaks-panel.jsx` are **design-tool scaffolding** — do not port them. They render the iPhone bezel and the multi-artboard preview canvas only.

---

## Design Tokens

All values from `theme.jsx` → `FC_THEMES.midnight` (the canonical theme):

### Colors
```
bg              #0B1622   page background
bgGrad          linear-gradient(180deg, #0B1622 0%, #0E1A2A 60%, #0B1622 100%)
surface         #142233   secondary surface (sheets, headers)
card            #1A2D42   card surfaces
cardEdge        rgba(255,255,255,0.06)   card hairline border

text            #F1F5F9   primary text
text2           #94A3B8   secondary text
text3           #64748B   tertiary / labels

accent          #00C9A7   sea foam green — scores ≥70, primary CTAs, "now" markers
blue            #3B82F6   ocean blue — tide curve, water data
amber           #F59E0B   caution / scores 40–69 / "falling" trend
red             #EF4444   bad / scores <40 / wind ≥19 mph
green           #10B981   great / scores ≥70 / wind <13 mph
```

### Score → Color Rule (from `theme.jsx`)
```
score ≥ 70  → green (#10B981)
score 40–69 → amber (#F59E0B)
score < 40  → red   (#EF4444)
```

### Score → Label Rule
```
≥ 85  "Drop everything and go"
≥ 70  "Great day to fish"
≥ 55  "Decent — pick your window"
≥ 40  "Tough but possible"
< 40  "Stay home"
```

### Typography
- **Body / labels / system UI:** system sans (`-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui`)
- **Numbers (scores, tide heights, times, wind, pressure):** `ui-monospace, "SF Mono", Menlo, monospace` with `font-variant-numeric: tabular-nums` and `font-feature-settings: "tnum"` enabled. Tabular numerics are NOT optional — they keep numbers from jittering as they update.
- **Weights used:** 400, 500, 600, 700
- **Letter-spacing:** `-2` on giant score numbers, `-0.5` on stat-card values, `-0.2 to -0.6` on titles, positive spacing (`0.6–2.5`) on uppercase labels.

### Spacing & Sizing
- **Phone canvas:** 360 × 760 dp
- **Screen padding:** 18 dp horizontal (Comfy), 14 dp (Compact)
- **Card radius:** 18 dp (large), 14 dp (medium), 12 dp (small), 10 dp (compact rows), 99 dp (pills)
- **Card padding:** 14 dp default, 12 dp medium, 10 dp small
- **Card border:** `0.5px solid rgba(255,255,255,0.06)` (use `StyleSheet.hairlineWidth` in RN)
- **TabBar height:** ~60 dp content + bottom safe area; floats over content with a `linear-gradient(to top, bg, transparent)` fade

---

## Screens

### 1. Dashboard (Comfy variant) — `DashboardComfy`

**Purpose:** The default screen on app open. Show the user the fishing score for their current spot, the best window of the day, and all supporting conditions at a glance.

**Layout (top to bottom):**

1. **Header strip** — `ScreenHeader` component
   - Pin icon (accent color) + spot name (16 dp, weight 700) + region/type subtitle (10.5 dp, text2)
   - Right side: bell icon button + cog icon button, both 32×32 in `rgba(255,255,255,0.06)` circles
   - Padding: `12px 18px 10px`

2. **Hero score block** (centered, padding `8px 18px 22px`)
   - **`ScoreRing`** — 210 dp diameter, 9 dp stroke
     - Track: `rgba(255,255,255,0.06)`
     - Fill: linear gradient of the score color (top 0.55 → bottom 1.0 opacity), `strokeLinecap: round`, dasharray = `(score/100) * circumference`
     - 12 tick marks around the outside (every 5/60 segments)
     - Center: score number (size = ring × 0.42, weight 700, score color, monospace, letter-spacing -2) over an uppercase "FISHING SCORE" label (9 dp, text3, letter-spacing 2.5)
   - Below ring: score label text (17 dp, weight 600)
   - "Best window" pill: `5px 11px` padding, radius 99, background `accent + 15% alpha`, border `accent + 40% alpha`, contains "BEST" tag (10 dp, accent, uppercase) + time range (12 dp, text, mono) + score (12 dp, accent, weight 700)

3. **Hourly Score timeline card**
   - Section header "HOURLY SCORE" + right-aligned time range
   - 16 vertical bars, one per hour from 5A–8P
   - Bar color follows score color rule; the peak bar gets full opacity, a glowing box-shadow (`0 0 12px {color}88`), and a 1 px outline frame (`{color}` at 0.5 opacity)
   - Hour label below each bar (8.5 dp, mono, peak label = text/weight 700, others = text3)

4. **Stat row** — 3-column grid, gap 8 dp: Wind / Tide / Water
   - `StatCard`: card padding `12px 12px 11px`, min-height 78 dp
   - Top row: small icon (text3) + uppercase label (10 dp, weight 600, letter-spacing 0.6, text3)
   - Big value (22 dp, weight 700, monospace, color = score-bucketed accent or default text)
   - Bottom row: sub-line (11 dp, text2, mono)
   - Wind value color depends on speed: ≥19 red, ≥13 amber, else green
   - In **freshwater mode** (`conditions.noTide === true`), the Tide card becomes "Lake / Calm / No tides"

5. **Tide curve card** (skip entirely if `noTide`)
   - Header "TIDE" + right-aligned "Next H 3:42 PM · 5.1'"
   - **`TideCurve`** SVG, 320 × 120 viewBox, preserveAspectRatio "none" so it stretches to card width
     - Smooth bezier through 24 hourly points
     - Fill below curve: linear gradient `blue` 0.4 → 0 alpha
     - Stroke: `blue`, 1.6 px, round caps
     - 2 dashed gridlines at y = 33% and 66%
     - "Now" line: dashed vertical line at current hour in `accent`, plus an 8 dp accent halo + 3.5 dp accent dot at the curve point
     - Event markers: small `text2` dot at each high/low; text "H 5.1'" above highs, "L 0.3'" below lows (8.5 dp, mono, weight 600)
     - Bottom labels: 12A, 6A, 12P, 6P (9 dp, text3, mono)

6. **Conditions grid** — section header + 3-column grid of `StatCard`s, gap 8 dp
   - Pressure (with falling/rising trend icon in sub)
   - Swell (height + period + direction)
   - Air (current temp + H/L sub)
   - Sky (rain chance + condition name)
   - Moon (illumination % + Major period; uses `MoonGlyph` 14 dp icon)
   - Sun (sunset time + sunrise sub)

7. **What's Biting list** — section header "WHAT'S BITING" + count
   - Vertical stack of 3 `SpeciesRow`s, gap 7 dp
   - Each row: `card` background, radius 13, padding `10px 12px`, hairline border
     - 38 dp icon tile (radius 10, `rgba(255,255,255,0.04)` bg) containing a 26 dp `FishGlyph` colored by species score
     - Name (14 dp, weight 700) + status pill (9 dp, weight 700, uppercase, color = green for Peak, blue for Active, text3 for Present)
     - Tip line (11 dp, text2, single-line ellipsis)
     - Right: big score number (18 dp, weight 700, score color, mono) + "SCORE" label below (8 dp, text3)
     - Chevron right at the end (text3, 14 dp)

8. **TabBar** (positioned absolute, bottom)
   - 4 tabs: Today (gauge icon), Spots (pin), Biting (fish), Settings (cog)
   - Active tab uses `accent` color; inactive uses `text3`
   - Icons 22 dp, label below (10 dp, weight 700 active / 500 inactive)

**Interactions:**
- Tap a `SpeciesRow` → push **Species Detail** for that species
- Tap header cog → push **Settings**
- Tap header pin/name → open spot picker (out of MVP — show toast or no-op for now)
- Tab bar taps → switch root screen
- Pull-to-refresh on dashboard → re-fetch conditions (Phase B — show 12-min stale label for now)

---

### 2. Spots List — `SpotsList`

**Purpose:** Saved spots, ranked by current fishing score, current/nearest spot highlighted.

**Layout:**

- Title block: "Spots" (28 dp, weight 700, letter-spacing -0.6) + subtitle "{count} saved · sorted by score" (12 dp, text2)
- Vertical stack of spot rows + an "Add a spot" dashed-border CTA at the bottom
- **First row** (currently active spot) gets:
  - Border `1px solid {accent}55` (instead of hairline)
  - Outer halo: `box-shadow: 0 0 0 3px {accent}11`
  - "NOW" pill next to name: 8 dp accent text, 1px 5px padding, `accent + 22%` background, radius 4
- Each row layout:
  - Left: stacked score (26 dp, weight 700, score-color, mono) + 30×3 score-color underline at 0.5 opacity
  - Middle: spot name (15 dp, weight 700) + region · distance subtitle (11 dp, text2) + bottom row of mini stats (10 dp, text3, mono): wind icon + "8SW", thermo + "62°", wave + "Rising" (omit wave if freshwater)
  - Right: chevron (text3)
- "Add a spot" button: dashed `cardEdge` border, accent text, plus icon, padding 14, radius 16

**Interactions:**
- Tap a row → switch dashboard's active spot and pop to dashboard
- Tap "Add a spot" → push **Add Spot** map picker
- Long-press a row → reorder/delete (Phase B)

---

### 3. Add Spot (map picker) — `AddSpot`

**Purpose:** Drop a pin on the map and save it as a spot.

**Layout:**

- **Map background** (full-bleed, behind the sheet): a stylized nautical chart drawn in SVG
  - Linear gradient sea (`surface` → `bg`)
  - 40-dp grid pattern overlay at 0.04 alpha
  - 4 dashed depth contours in `blue` at 15–28% alpha
  - Two abstract land masses in `surface` with `cardEdge` outline
  - Small label callouts: "LONG ISLAND" (text3, 9 dp, letter-spacing 2), "Atlantic" (blue italic), "38 ft" / "12 ft" depth markers (text3 at 0.5 alpha)
  - Compass rose (top-right): 22 dp circle outline, north arrow, "N" letter
  - Three pins: 1 selected (accent halo + 6 dp solid accent dot with 1.5 dp white ring) + 2 muted (text3 with thin white ring)
- **Top bar** (over map): back chevron button + search field — both `rgba(20,34,51,0.85)` with 10 dp blur, hairline border, radius 99
- **Pin callout** (anchored to selected pin): card background, accent border tint, "New spot" label (11 dp, weight 600), small triangular tail
- **Bottom sheet** (rises from bottom):
  - Background: `surface`, top corners radius 22, top hairline border, large drop shadow `0 -8px 30px rgba(0,0,0,0.4)`
  - Drag handle (36×4, text3 at 0.4 alpha)
  - Title "Drop a pin" (18 dp, weight 700)
  - Subtitle "Drag the map to position · Nearest NOAA station: Montauk · 2.3 mi" (11.5 dp, text2)
  - **Name field**: uppercase "NAME" label (9 dp, text3) + card-styled text input showing "Montauk Point" with a blinking accent caret
  - **Type segmented control**: 2-option "Saltwater / Freshwater" segmented control. Selected segment uses `accent + 22%` bg, `accent + 66%` border, accent text; unselected is plain text3
  - Primary CTA: full-width "Save spot" button — accent fill, `#04221C` text (the deep teal-black is intentional for AA contrast on accent), radius 11, glow shadow `0 4px 14px {accent}55`

**Interactions:**
- Drag the map → reposition the pin (snap callout follows)
- Tap a search field → enter geocoding flow (Phase B — out of MVP, show stub)
- Toggle Saltwater/Freshwater → updates downstream defaults
- Tap "Save spot" → return to Spots List with new spot inserted, score TBD (Phase B)

---

### 4. Species Detail — `SpeciesDetail`

**Purpose:** Drill-down for a single species: why this score, when they're active, what they prefer, and a daily tip.

**Layout:**

1. **Top bar:** back chevron only.

2. **Hero row** (`0 18px 16px`):
   - 72 dp rounded square (radius 18) with score-color radial gradient bg + `score-color + 55%` border, containing a 48 dp `FishGlyph` in score color
   - Middle: species common name (22 dp, weight 700, letter-spacing -0.4) + scientific name italic (11 dp, text2) + status pill (green dot + uppercase status label)
   - Right: big score (32 dp, weight 700, score color, mono) + "SCORE" label

3. **Seasonal Activity card**
   - Section header "SEASONAL ACTIVITY" + right-aligned "May · peak"
   - **`SpeciesActivityBar`**: 12-month grid (J F M A M J J A S O N D)
     - Each cell: 18 dp tall, radius 3
     - Peak month → solid `green`
     - Present month → `green + 55% alpha`
     - Absent → `rgba(255,255,255,0.05)`
     - Current month → `1.5px solid accent` border (regardless of fill)
     - Month letter below: text3 default; current = accent + weight 700
   - Legend row: Peak / Present / Now swatches with small color chips

4. **"Why score 88?" breakdown card** (no padding on container, padded rows inside)
   - 4 rows separated by hairlines:
     - **Month** — 40/40 — "Peak month — May" (green)
     - **Water Temp** — 28/30 — "In range (62°F — ideal 55–65°F)" (green)
     - **Tide** — 13/15 — "Incoming — preferred" (green)
     - **Time of Day** — 7/15 — "Approaching dusk — prime time" (amber)
   - Each row: 4×28 dp colored vertical bar + label (12 dp, weight 700) + detail (10.5 dp, text2) + score "X / Y" (13 dp, weight 700, mono, colored to match its bar)

5. **Preferred Conditions** — 2-column grid of small cards
   - Water Temp: "55–65°F peak" + tolerance line
   - Tide: "Incoming" + "Last 2 hrs of flood"
   - Time: "Dawn · Dusk · Night" + "Low-light feeders"
   - Structure: "Rocky points" + "Jetties, inlets, river mouths"

6. **Today's Tip card**
   - Background: linear gradient `accent + 22%` → `accent + 8%`
   - Border: `accent + 55%`
   - Lightbulb emoji + "TODAY'S TIP" label (9 dp, accent, uppercase, letter-spacing 1.2) + tip body (12.5 dp, text, line-height 1.4)

**Interactions:**
- Back chevron → pop
- (Phase B) Tap "Why score 88?" rows → expand explanation drawer

---

### 5. Settings — `Settings`

**Purpose:** Account, units, alerts, about. Plus the FishCast Pro upsell card at the top.

**Layout:**

- Title "Settings" (28 dp, weight 700, letter-spacing -0.6)
- **Pro card** (16 dp horizontal padding):
  - 14×16 padding, radius 16
  - Background: linear gradient `accent + 33%` → `blue + 22%`
  - Border: `accent + 55%`
  - 38 dp solid-accent square badge with white "PRO" text (`#04221C`, weight 700) — keeps brand-dark text on accent for contrast
  - Title "FishCast Pro" + subtitle "Unlimited spots · 7-day forecast · alerts"
  - Right: "$2.99/mo" in accent, mono
- **Grouped sections** (iOS-style): Alerts / Units / Account / About
  - Each group: section header + a single `Card` containing rows separated by hairlines
  - Row: label (13 dp, text) + optional value (12 dp, text2, mono) + tail control (chevron / toggle / nothing)
  - Toggle pill: 32×19, accent-on uses `green` (#10B981), off uses `rgba(255,255,255,0.15)`; 15 dp white knob with shadow
- Footer: "FishCast v1.0 (build 142)" (10 dp, text3, mono, centered)

**Interactions:**
- Tap any row → push respective sub-screen (most are stubs in MVP)
- Toggle push notifications → enable/disable system push permission
- Tap Pro card → open subscription flow (Phase B with RevenueCat)

---

## Reusable Components Spec

### `ScoreRing({ score, size, stroke })`
Circular SVG progress ring with a giant centered number. Used in dashboard hero. See "Hero score block" above for details. Score color comes from `scoreColor(score)`.

### `ScoreNumber({ score, size })`
Just-the-number variant: huge mono numeral with a `0 0 30px {color}33` text-shadow halo, paired with a "/100" sub-glyph at 18% of the main size.

### `TideCurve({ data, currentHour, height, showLabels, events })`
24-point smooth bezier with gradient fill, "now" indicator, and optional event markers/axis labels. Use `react-native-svg` `Path` with `d=` strings; `Defs` for the linear gradient.

### `ScoreTimeline({ data, height, density })`
Vertical bars colored per score; peak bar gets a glow shadow and outline frame.

### `WindDial({ wind, size })`
Compass: 32 dp outer ring, 24 dp inner dashed ring, NESW labels, rotated arrow head + tail. Arrow color from wind speed buckets.

### `MoonGlyph({ illumination, size })`
SVG: full-circle background + a single elliptical-radius `Path` whose horizontal radius = `r * |1 - 2*illumination/100|` and sweep flag based on waxing/waning.

### `FishGlyph({ color, size })`
Stylized side-view fish with gradient fill, eye dot, and gill marks. Pure SVG path — port directly to `react-native-svg`.

### `SpeciesActivityBar({ months, peakMonths, currentMonth })`
12-cell calendar heatmap. See **Species Detail → Seasonal Activity**.

### `StatCard({ icon, label, value, sub, accent })` / `MiniStat` / `InstrumentTile`
Generic data tile primitives — different sizes for different layouts. The Comfy dashboard uses the largest variant (`StatCard`).

### `SectionHeader({ title, right })`
Uppercase 10-dp text3 letter-spaced 1.5 px label with optional right-aligned secondary text.

### `Card({ padding, children })`
Background `card`, radius 18, hairline border. Used everywhere a content block needs separation from the page bg.

### `TabBar({ active, onChange })`
Floating bottom nav, 4 tabs, gradient fade overlay at the top so content scrolls cleanly under it.

---

## Mock Data Contract

Real API integration is Phase B in the plan. For now, port `data.jsx` to a `mockApi.ts` module with the same shapes:

- `MOCK_SPOT` — `{ id, name, region, lat, lng, type }`
- `MOCK_SPOTS` — array, with score + summary stats per row
- `MOCK_CONDITIONS` — `{ fishingScore, scoreLabel, bestWindow, wind, tide, water, air, pressure, swell, sky, sun, moon, hourlyScores }`
  - Note `tide.hourlyCurve`: 24-point array of heights in feet
  - Note `tide.events`: array of `{ type: 'high'|'low', time: 'h:mm A/PM', height }`
  - **For freshwater mode**, set `conditions.noTide = true` and skip ALL tide UI (the Comfy dashboard already gates this)
- `MOCK_SPECIES` — array, with `range`, `months`, `peakMonths`, `tip`, etc.

The plan's `## 7. Static Data / Mock Data Guide` section is the canonical reference; the JSX mock matches it.

---

## Behavior Notes (Comfy variant in particular)

- **Score color must update everywhere consistently.** The single rule from `scoreColor(score)` drives: ring stroke, ring center number, score label color in compact, mini bars, species score, hero timeline peak, and stat values that have score-conditional accents (wind speed). Make `scoreColor` the only source of truth.
- **Numbers must use tabular figures.** When the score ticks up from 79 to 80, the digits shouldn't shift horizontally.
- **The Comfy dashboard scrolls.** Header is in the scroll body, not pinned. Only the TabBar floats.
- **TabBar fade-out background** is important — without it, scrolling content visually collides with the icons.
- **Status updates and stale state** are out of MVP — the "Updated 12 min ago" text in some variants is a static placeholder.

---

## Out of Scope for MVP

- Live data — everything is static (Phase B in the plan)
- 7-day forecast / hourly drill-down beyond the 16-bar timeline
- Push notifications wiring (UI only)
- Spot sharing, social, log book
- Light theme (Midnight only ships in v1; Dawn and Reef are kept as future palettes in `theme.jsx`)
- Watch / widget / iPad layouts

---

## Suggested Implementation Order

1. **Scaffolding** — Expo + TS + React Navigation native stack + bottom-tabs from the plan's "Tech Stack" section. Drop in `theme.ts` (port `FC_THEMES.midnight`) and the icon set.
2. **Reusable widgets** — `ScoreRing`, `TideCurve`, `ScoreTimeline`, `WindDial`, `MoonGlyph`, `FishGlyph`, `Card`, `StatCard`, `SectionHeader`, `TabBar`. Verify each in isolation with Storybook or a sandbox screen.
3. **Dashboard (Comfy)** — wire up against `mockApi.getConditions()`, hard-coded to Montauk Point.
4. **Spots List** — `mockApi.getSpots()`. Wire row tap to switch the dashboard's spot.
5. **Add Spot** — start with the bottom sheet only; wire `react-native-maps` later. The stylized chart is decorative — for production, use real map tiles and only the bottom sheet UI from this design.
6. **Species Detail** — `mockApi.getSpecies(id)`. Wire from the dashboard's "What's Biting" rows.
7. **Settings** — pure static rows.

Once all 5 screens render correctly with mock data, follow Phase B in the plan to swap each data source for live APIs.
