// screens.jsx — FishCast screens (Dashboard variants, Spots List, Add Spot, Species Detail, Settings)

// ── Header (in-screen, sits below status bar) ─────────────────────────
function ScreenHeader({ t, spot, onMenu, density = 'regular' }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: density === 'compact' ? '6px 16px 8px' : '12px 18px 10px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {Icon.pin(t.accent, 16)}
        <div>
          <div style={{ fontSize: 16, fontWeight: 700, color: t.text, letterSpacing: -0.2 }}>{spot.name}</div>
          <div style={{ fontSize: 10.5, color: t.text2, ...TAB }}>{spot.region} · {spot.type === 'saltwater' ? 'Saltwater' : 'Freshwater'}</div>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 4 }}>
        <button style={{ background: 'rgba(255,255,255,0.06)', border: 0, padding: 7, borderRadius: 99, cursor: 'pointer' }}>
          {Icon.bell(t.text2, 16)}
        </button>
        <button onClick={onMenu} style={{ background: 'rgba(255,255,255,0.06)', border: 0, padding: 7, borderRadius: 99, cursor: 'pointer' }}>
          {Icon.cog(t.text2, 16)}
        </button>
      </div>
    </div>
  );
}

// ── DASHBOARD — Variant A: Comfy / Hero ──────────────────────────────
function DashboardComfy({ t, conditions, spot, hourly, species }) {
  const score = conditions.fishingScore;
  return (
    <div style={{ background: t.bgGrad, color: t.text, minHeight: '100%', paddingBottom: 90 }}>
      <ScreenHeader t={t} spot={spot} density="comfy" />
      {/* HERO */}
      <div style={{ padding: '8px 18px 22px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
        <ScoreRing score={score} t={t} size={210} stroke={9} />
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 17, fontWeight: 600, color: t.text, marginBottom: 4 }}>{scoreLabel(score)}</div>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '5px 11px', borderRadius: 99,
            background: `${t.accent}15`, border: `0.5px solid ${t.accent}40`,
          }}>
            <span style={{ fontSize: 10, fontWeight: 700, color: t.accent, letterSpacing: 0.8, textTransform: 'uppercase' }}>Best</span>
            <span style={{ fontSize: 12, color: t.text, ...TAB, fontWeight: 600 }}>
              {conditions.bestWindow.start}–{conditions.bestWindow.end}
            </span>
            <span style={{ fontSize: 12, color: t.accent, fontWeight: 700, ...TAB }}>{conditions.bestWindow.score}</span>
          </div>
        </div>
      </div>
      {/* TIMELINE */}
      <div style={{ padding: '0 18px 18px' }}>
        <Card t={t} padding={14}>
          <SectionHeader t={t} title="Hourly Score" right={<span style={{ ...TAB }}>5A — 8P</span>} />
          <ScoreTimeline data={hourly} t={t} height={68} density="comfy" />
        </Card>
      </div>
      {/* STAT ROW */}
      <div style={{ padding: '0 18px 14px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
        <StatCard t={t} icon={Icon.wind(t.text3, 14)} label="Wind"
          value={`${conditions.wind.speed}`}
          sub={`${conditions.wind.directionLabel} · g${conditions.wind.gusts}mph`}
          accent={conditions.wind.speed >= 19 ? t.red : conditions.wind.speed >= 13 ? t.amber : t.green} />
        <StatCard t={t} icon={Icon.wave(t.text3, 14)} label={conditions.noTide ? 'Lake' : 'Tide'}
          value={conditions.noTide ? 'Calm' : `${conditions.tide.current.height}'`}
          sub={conditions.noTide ? 'No tides' : `${conditions.tide.current.rising ? '↑ Rising' : '↓ Falling'} · H ${conditions.tide.next.time.replace(' ', '')}`} />
        <StatCard t={t} icon={Icon.thermo(t.text3, 14)} label="Water"
          value={`${conditions.water.temp}°`}
          sub="In bass range" accent={t.blue} />
      </div>
      {/* TIDE CURVE */}
      {!conditions.noTide && (
      <div style={{ padding: '0 18px 14px' }}>
        <Card t={t} padding={12}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '0 4px 4px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: t.text3, letterSpacing: 1.5, textTransform: 'uppercase' }}>Tide</div>
            <div style={{ fontSize: 11, color: t.text2, ...TAB }}>
              Next <span style={{ color: t.text, fontWeight: 600 }}>H {conditions.tide.next.time}</span> · {conditions.tide.next.height}'
            </div>
          </div>
          <TideCurve data={conditions.tide.hourlyCurve} currentHour={11} t={t} height={120} events={conditions.tide.events} />
        </Card>
      </div>
      )}
      {/* CONDITIONS GRID */}
      <div style={{ padding: '0 18px 14px' }}>
        <SectionHeader t={t} title="Conditions" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          <StatCard t={t} icon={Icon.gauge(t.text3, 14)} label="Pressure"
            value={conditions.pressure.value.toFixed(2)}
            sub={<span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>{Icon.trendDown(t.amber, 11)} falling</span>} />
          <StatCard t={t} icon={Icon.wave(t.text3, 14)} label="Swell"
            value={`${conditions.swell.height}'`}
            sub={`${conditions.swell.period}s · ${conditions.swell.directionLabel}`} />
          <StatCard t={t} icon={Icon.thermo(t.text3, 14)} label="Air"
            value={`${conditions.air.temp}°`}
            sub={`H ${conditions.air.high}° · L ${conditions.air.low}°`} />
          <StatCard t={t} icon={Icon.cloud(t.text3, 14)} label="Sky"
            value={`${conditions.sky.rain_chance}%`}
            sub={conditions.sky.condition} />
          <StatCard t={t} icon={<MoonGlyph illumination={conditions.moon.illumination} t={t} size={14} />} label="Moon"
            value={`${conditions.moon.illumination}%`}
            sub="Major 2:15p" />
          <StatCard t={t} icon={Icon.sun(t.text3, 14)} label="Sun"
            value={conditions.sun.sunset.replace(' ', '')}
            sub={`Rise ${conditions.sun.sunrise.replace(' ', '')}`} />
        </div>
      </div>
      {/* WHAT'S BITING */}
      <div style={{ padding: '0 18px 22px' }}>
        <SectionHeader t={t} title="What's Biting" right="3 species" />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
          {species.map(sp => <SpeciesRow key={sp.name} sp={sp} t={t} />)}
        </div>
      </div>
    </div>
  );
}

// ── DASHBOARD — Variant B: Regular / Balanced ─────────────────────────
function DashboardRegular({ t, conditions, spot, hourly, species }) {
  const score = conditions.fishingScore;
  const col = scoreColor(score, t);
  return (
    <div style={{ background: t.bgGrad, color: t.text, minHeight: '100%', paddingBottom: 90 }}>
      <ScreenHeader t={t} spot={spot} />
      {/* HERO — split layout: number + best window */}
      <div style={{ padding: '6px 18px 14px' }}>
        <Card t={t} padding={16}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <ScoreRing score={score} t={t} size={130} stroke={7} />
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div>
                <div style={{ fontSize: 14, color: t.text, fontWeight: 600, lineHeight: 1.15 }}>{scoreLabel(score)}</div>
                <div style={{ fontSize: 11, color: t.text2, marginTop: 2 }}>Updated 12 min ago</div>
              </div>
              <div style={{ borderTop: `0.5px solid ${t.cardEdge}`, paddingTop: 8 }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: t.accent, letterSpacing: 1.4, textTransform: 'uppercase', marginBottom: 2 }}>Best Window</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                  <div style={{ fontSize: 16, color: t.text, fontWeight: 700, ...TAB }}>{conditions.bestWindow.start}–{conditions.bestWindow.end}</div>
                  <div style={{ fontSize: 12, color: col, fontWeight: 700, ...TAB }}>· {conditions.bestWindow.score}</div>
                </div>
              </div>
            </div>
          </div>
          <div style={{ marginTop: 14, paddingTop: 12, borderTop: `0.5px solid ${t.cardEdge}` }}>
            <ScoreTimeline data={hourly} t={t} height={56} />
          </div>
        </Card>
      </div>
      {/* QUICK STATS */}
      <div style={{ padding: '0 18px 12px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 7 }}>
        <MiniStat t={t} icon={Icon.wind(t.text3, 12)} label="Wind" value={`${conditions.wind.speed}`} sub={conditions.wind.directionLabel} />
        <MiniStat t={t} icon={Icon.wave(t.text3, 12)} label={conditions.noTide ? 'Lake' : 'Tide'}
          value={conditions.noTide ? 'Calm' : `${conditions.tide.current.height}'`}
          sub={conditions.noTide ? '' : (conditions.tide.current.rising ? '↑' : '↓')} />
        <MiniStat t={t} icon={Icon.thermo(t.text3, 12)} label="Water" value={`${conditions.water.temp}°`} />
        <MiniStat t={t} icon={Icon.gauge(t.text3, 12)} label="Press" value={conditions.pressure.value.toFixed(2)} sub="↘" subColor={t.amber} />
      </div>
      {/* TIDE CURVE */}
      {!conditions.noTide && (
      <div style={{ padding: '0 18px 12px' }}>
        <Card t={t} padding={12}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '0 2px 4px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: t.text3, letterSpacing: 1.5, textTransform: 'uppercase' }}>Tide · Today</div>
            <div style={{ fontSize: 11, color: t.text2, ...TAB }}>{conditions.tide.current.height}' now</div>
          </div>
          <TideCurve data={conditions.tide.hourlyCurve} currentHour={11} t={t} height={100} events={conditions.tide.events} />
        </Card>
      </div>
      )}
      {/* CONDITIONS GRID — 2 col compact */}
      <div style={{ padding: '0 18px 12px', display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
        <Card t={t} padding={12} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <WindDial wind={conditions.wind} t={t} size={56} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: t.text3, letterSpacing: 1, textTransform: 'uppercase' }}>Wind</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: t.text, ...TAB, lineHeight: 1.05 }}>
              {conditions.wind.speed} <span style={{ fontSize: 11, color: t.text3, fontWeight: 500 }}>mph</span>
            </div>
            <div style={{ fontSize: 10.5, color: t.text2, ...TAB }}>{conditions.wind.directionLabel} · g{conditions.wind.gusts}</div>
          </div>
        </Card>
        <Card t={t} padding={12} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <MoonGlyph illumination={conditions.moon.illumination} t={t} size={42} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: t.text3, letterSpacing: 1, textTransform: 'uppercase' }}>Moon</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: t.text, ...TAB, lineHeight: 1.05 }}>
              {conditions.moon.illumination}<span style={{ fontSize: 11, color: t.text3, fontWeight: 500 }}>%</span>
            </div>
            <div style={{ fontSize: 10.5, color: t.text2 }}>Major 2:15p</div>
          </div>
        </Card>
        <Card t={t} padding={12}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: t.text3, marginBottom: 4 }}>
            {Icon.cloud(t.text3, 12)}
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Sky</div>
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, color: t.text }}>{conditions.sky.condition}</div>
          <div style={{ fontSize: 11, color: t.text2 }}>Rain {conditions.sky.rain_chance}% · Air {conditions.air.temp}°</div>
        </Card>
        <Card t={t} padding={12}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: t.text3, marginBottom: 4 }}>
            {Icon.sun(t.text3, 12)}
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Sun</div>
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, color: t.text, ...TAB }}>{conditions.sun.sunrise} · {conditions.sun.sunset}</div>
          <div style={{ fontSize: 11, color: t.text2 }}>Day length 14h 30m</div>
        </Card>
      </div>
      {/* WHAT'S BITING */}
      <div style={{ padding: '0 18px 22px' }}>
        <SectionHeader t={t} title="What's Biting" right="3 species" />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
          {species.map(sp => <SpeciesRow key={sp.name} sp={sp} t={t} />)}
        </div>
      </div>
    </div>
  );
}

// ── DASHBOARD — Variant C: Compact / Instrument-Panel ────────────────
function DashboardCompact({ t, conditions, spot, hourly, species }) {
  const score = conditions.fishingScore;
  const col = scoreColor(score, t);
  return (
    <div style={{ background: t.bgGrad, color: t.text, minHeight: '100%', paddingBottom: 88 }}>
      <ScreenHeader t={t} spot={spot} density="compact" />
      {/* TOP STRIP */}
      <div style={{ padding: '0 14px 10px' }}>
        <Card t={t} padding={12} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 78 }}>
            <ScoreNumber score={score} t={t} size={56} />
            <div style={{ fontSize: 9, color: col, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', marginTop: 2 }}>{scoreLabel(score).split('—')[0].trim()}</div>
          </div>
          <div style={{ flex: 1, borderLeft: `0.5px solid ${t.cardEdge}`, paddingLeft: 10 }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: t.accent, letterSpacing: 1, textTransform: 'uppercase' }}>Best</div>
            <div style={{ fontSize: 14, color: t.text, fontWeight: 700, ...TAB, lineHeight: 1.1 }}>{conditions.bestWindow.start}–{conditions.bestWindow.end}</div>
            <div style={{ fontSize: 10.5, color: t.text2, ...TAB }}>peak {conditions.bestWindow.score}/100</div>
            <div style={{ marginTop: 6 }}>
              <ScoreTimeline data={hourly} t={t} height={28} density="compact" />
            </div>
          </div>
        </Card>
      </div>
      {/* INSTRUMENT GRID */}
      <div style={{ padding: '0 14px 10px', display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 6 }}>
        <InstrumentTile t={t} icon={Icon.wind(t.text3, 12)} label="Wind"
          value={`${conditions.wind.speed} mph`} dial={<WindDial wind={conditions.wind} t={t} size={42} />}
          sub={`${conditions.wind.directionLabel} · g${conditions.wind.gusts}`} />
        <InstrumentTile t={t} icon={Icon.wave(t.text3, 12)} label={conditions.noTide ? 'Lake' : 'Tide'}
          value={conditions.noTide ? 'Calm' : `${conditions.tide.current.height}'`}
          sub={conditions.noTide ? 'No tides' : `${conditions.tide.current.rising ? '↑' : '↓'} H ${conditions.tide.next.time.replace(' ', '')}`}
          accent={t.blue} />
        <InstrumentTile t={t} icon={Icon.thermo(t.text3, 12)} label="Water" value={`${conditions.water.temp}°F`} sub="Bass: ideal" accent={t.blue} />
        <InstrumentTile t={t} icon={Icon.gauge(t.text3, 12)} label="Pressure"
          value={conditions.pressure.value.toFixed(2)}
          sub={<span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, color: t.amber }}>{Icon.trendDown(t.amber, 10)} falling</span>} />
        <InstrumentTile t={t} icon={Icon.cloud(t.text3, 12)} label="Sky"
          value={`${conditions.sky.rain_chance}%`} sub={conditions.sky.condition} />
        <InstrumentTile t={t} icon={Icon.thermo(t.text3, 12)} label="Air" value={`${conditions.air.temp}°`} sub={`H${conditions.air.high} L${conditions.air.low}`} />
        <InstrumentTile t={t} icon={<MoonGlyph illumination={conditions.moon.illumination} t={t} size={14} />} label="Moon"
          value={`${conditions.moon.illumination}%`} sub="Major 2:15p" />
        <InstrumentTile t={t} icon={Icon.sun(t.text3, 12)} label="Sun" value={conditions.sun.sunset.replace(' ','')} sub={`↑ ${conditions.sun.sunrise.replace(' ','')}`} />
      </div>
      {/* TIDE STRIP */}
      {!conditions.noTide && (
      <div style={{ padding: '0 14px 10px' }}>
        <Card t={t} padding={10}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '0 2px 2px' }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: t.text3, letterSpacing: 1.4, textTransform: 'uppercase' }}>Tide</div>
            <div style={{ fontSize: 10, color: t.text2, ...TAB }}>L {conditions.tide.events[0].time.replace(' ','')} · H {conditions.tide.events[1].time.replace(' ','')}</div>
          </div>
          <TideCurve data={conditions.tide.hourlyCurve} currentHour={11} t={t} height={70} events={[]} showLabels={false} />
        </Card>
      </div>
      )}
      {/* WHAT'S BITING — compact rows */}
      <div style={{ padding: '0 14px 22px' }}>
        <SectionHeader t={t} title="Biting" right="3" />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
          {species.map(sp => <SpeciesRowCompact key={sp.name} sp={sp} t={t} />)}
        </div>
      </div>
    </div>
  );
}

// ── Helpers used by dashboards ──────────────────────────────────────
function MiniStat({ t, icon, label, value, sub, subColor }) {
  return (
    <div style={{
      background: t.card, borderRadius: 12, padding: '8px 9px',
      border: `0.5px solid ${t.cardEdge}`,
      display: 'flex', flexDirection: 'column', gap: 1,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: t.text3 }}>
        {icon}
        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase' }}>{label}</div>
      </div>
      <div style={{ fontSize: 15, fontWeight: 700, color: t.text, ...TAB, lineHeight: 1.15,
        fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>{value}
        {sub && <span style={{ fontSize: 9, color: subColor || t.text3, fontWeight: 500, marginLeft: 3 }}>{sub}</span>}
      </div>
    </div>
  );
}

function InstrumentTile({ t, icon, label, value, sub, dial, accent }) {
  return (
    <div style={{
      background: t.card, borderRadius: 11, padding: '8px 10px',
      border: `0.5px solid ${t.cardEdge}`,
      display: 'flex', alignItems: 'center', gap: 8, minHeight: 46,
    }}>
      {dial || <div style={{ width: 24, height: 24, borderRadius: 6, background: 'rgba(255,255,255,0.04)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</div>}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 9, color: t.text3, fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase' }}>{label}</div>
        <div style={{ fontSize: 14, color: accent || t.text, fontWeight: 700, ...TAB, lineHeight: 1.1,
          fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>{value}</div>
        {sub && <div style={{ fontSize: 9.5, color: t.text2, ...TAB, marginTop: 1 }}>{sub}</div>}
      </div>
    </div>
  );
}

// ── Species rows ─────────────────────────────────────────────────────
function FishGlyph({ t, color = '#FFF', size = 30 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 30 30">
      <defs>
        <linearGradient id={`fg-${color.replace('#','')}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.4" />
          <stop offset="100%" stopColor={color} stopOpacity="0.15" />
        </linearGradient>
      </defs>
      <path d="M3 15 C 7 8, 15 7, 21 11 L 27 8 L 25 15 L 27 22 L 21 19 C 15 23, 7 22, 3 15 Z"
        fill={`url(#fg-${color.replace('#','')})`} stroke={color} strokeWidth="1.1" strokeLinejoin="round" />
      <circle cx="20" cy="13" r="0.8" fill={color} />
      <path d="M8 15 L11 13 M8 15 L11 17 M13 15 L16 13 M13 15 L16 17" stroke={color} strokeWidth="0.6" opacity="0.5" />
    </svg>
  );
}

function SpeciesRow({ sp, t }) {
  const col = scoreColor(sp.score, t);
  const statusColor = sp.status === 'Peak Season' ? t.green : sp.status === 'Active' ? t.blue : t.text3;
  return (
    <div style={{
      background: t.card, borderRadius: 13, padding: '10px 12px',
      border: `0.5px solid ${t.cardEdge}`,
      display: 'flex', alignItems: 'center', gap: 11,
    }}>
      <div style={{ width: 38, height: 38, borderRadius: 10, background: 'rgba(255,255,255,0.04)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <FishGlyph color={col} size={26} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 7, flexWrap: 'wrap' }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: t.text }}>{sp.name}</div>
          <div style={{ fontSize: 9, fontWeight: 700, color: statusColor, letterSpacing: 0.6, textTransform: 'uppercase' }}>{sp.status}</div>
        </div>
        <div style={{ fontSize: 11, color: t.text2, marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {sp.tip}
        </div>
      </div>
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1,
        padding: '2px 0', minWidth: 38,
      }}>
        <div style={{ fontSize: 18, fontWeight: 700, color: col, ...TAB, lineHeight: 1,
          fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>{sp.score}</div>
        <div style={{ fontSize: 8, color: t.text3, letterSpacing: 0.5, fontWeight: 600 }}>SCORE</div>
      </div>
      {Icon.chevR(t.text3, 14)}
    </div>
  );
}

function SpeciesRowCompact({ sp, t }) {
  const col = scoreColor(sp.score, t);
  return (
    <div style={{
      background: t.card, borderRadius: 10, padding: '6px 9px',
      border: `0.5px solid ${t.cardEdge}`,
      display: 'flex', alignItems: 'center', gap: 9,
    }}>
      <FishGlyph color={col} size={20} />
      <div style={{ flex: 1, fontSize: 12, fontWeight: 600, color: t.text }}>{sp.name}</div>
      <div style={{ fontSize: 10, color: t.text3, ...TAB }}>{sp.status}</div>
      <div style={{ fontSize: 14, fontWeight: 700, color: col, ...TAB, fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace', minWidth: 24, textAlign: 'right' }}>{sp.score}</div>
    </div>
  );
}

// ── SPOTS LIST ───────────────────────────────────────────────────────
function SpotsList({ t, spots }) {
  return (
    <div style={{ background: t.bgGrad, color: t.text, minHeight: '100%', paddingBottom: 90 }}>
      <div style={{ padding: '8px 18px 14px' }}>
        <div style={{ fontSize: 28, fontWeight: 700, color: t.text, letterSpacing: -0.6 }}>Spots</div>
        <div style={{ fontSize: 12, color: t.text2 }}>{spots.length} saved · sorted by score</div>
      </div>
      <div style={{ padding: '0 14px 0', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {spots.map((s, i) => {
          const col = scoreColor(s.score, t);
          return (
            <div key={s.id} style={{
              background: t.card, borderRadius: 16, padding: '12px 14px',
              border: i === 0 ? `1px solid ${t.accent}55` : `0.5px solid ${t.cardEdge}`,
              boxShadow: i === 0 ? `0 0 0 3px ${t.accent}11` : 'none',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 44 }}>
                <div style={{ fontSize: 26, fontWeight: 700, color: col, lineHeight: 1, ...TAB,
                  fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>{s.score}</div>
                <div style={{ width: 30, height: 3, background: col, opacity: 0.5, borderRadius: 2, marginTop: 4 }} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: t.text }}>{s.name}</div>
                  {i === 0 && <div style={{ fontSize: 8, color: t.accent, fontWeight: 700, letterSpacing: 0.8, textTransform: 'uppercase', padding: '1px 5px', background: `${t.accent}22`, borderRadius: 4 }}>Now</div>}
                </div>
                <div style={{ fontSize: 11, color: t.text2 }}>{s.region} · {s.distance}</div>
                <div style={{ display: 'flex', gap: 9, marginTop: 4, fontSize: 10, color: t.text3, ...TAB }}>
                  <span>{Icon.wind(t.text3, 10)} {s.wind}{s.dir}</span>
                  <span>{Icon.thermo(t.text3, 10)} {s.water}°</span>
                  {s.tide !== '—' && <span>{Icon.wave(t.text3, 10)} {s.tide}</span>}
                </div>
              </div>
              {Icon.chevR(t.text3, 14)}
            </div>
          );
        })}
        <button style={{
          background: 'transparent', border: `1px dashed ${t.cardEdge}`, color: t.accent,
          borderRadius: 16, padding: '14px', fontWeight: 600, fontSize: 13,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, cursor: 'pointer', marginTop: 4,
        }}>
          {Icon.plus(t.accent, 16)} Add a spot
        </button>
      </div>
    </div>
  );
}

// ── ADD SPOT (Map picker) ────────────────────────────────────────────
function AddSpot({ t }) {
  return (
    <div style={{ background: t.bg, color: t.text, minHeight: '100%', position: 'relative', overflow: 'hidden' }}>
      {/* "Map" — stylized nautical chart */}
      <div style={{ position: 'absolute', inset: 0 }}>
        <svg width="100%" height="100%" viewBox="0 0 360 760" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id="water-grad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={t.surface} />
              <stop offset="100%" stopColor={t.bg} />
            </linearGradient>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="360" height="760" fill="url(#water-grad)" />
          <rect width="360" height="760" fill="url(#grid)" />
          {/* depth contours */}
          {[1, 2, 3, 4].map(i => (
            <path key={i} d={`M ${-20 + i*30} ${300 + i*40} Q ${180} ${280 + i*30} ${380 - i*20} ${320 + i*50}`}
              fill="none" stroke={t.blue} strokeWidth="0.6" opacity={0.15 + i*0.04} strokeDasharray="3 5" />
          ))}
          {/* land mass */}
          <path d="M -20 200 C 50 180, 110 220, 160 200 C 220 180, 260 240, 300 220 C 340 210, 380 240, 380 240 L 380 -20 L -20 -20 Z"
            fill={t.surface} stroke={t.cardEdge} strokeWidth="1" />
          <path d="M 60 460 C 120 440, 200 470, 260 460 L 280 760 L 40 760 Z"
            fill={t.surface} stroke={t.cardEdge} strokeWidth="1" />
          {/* labels */}
          <text x="120" y="120" fill={t.text3} fontSize="9" letterSpacing="2" fontWeight="600">LONG ISLAND</text>
          <text x="280" y="380" fill={t.blue} fontSize="9" fontStyle="italic" opacity="0.7">Atlantic</text>
          <text x="220" y="420" fill={t.text3} fontSize="8" opacity="0.5">38 ft</text>
          <text x="100" y="500" fill={t.text3} fontSize="8" opacity="0.5">12 ft</text>
          {/* compass rose */}
          <g transform="translate(310, 110)">
            <circle r="22" fill="none" stroke={t.text3} strokeWidth="0.6" opacity="0.5" />
            <path d="M 0 -22 L 4 0 L 0 22 L -4 0 Z" fill={t.text2} opacity="0.7" />
            <text y="-26" textAnchor="middle" fill={t.text2} fontSize="8" fontWeight="700">N</text>
          </g>
          {/* existing pins */}
          <g transform="translate(170, 350)">
            <circle r="14" fill={t.accent} opacity="0.18" />
            <circle r="6" fill={t.accent} stroke="#fff" strokeWidth="1.5" />
          </g>
          <g transform="translate(90, 290)">
            <circle r="4" fill={t.text3} stroke="#fff" strokeWidth="1" />
          </g>
          <g transform="translate(250, 320)">
            <circle r="4" fill={t.text3} stroke="#fff" strokeWidth="1" />
          </g>
        </svg>
      </div>
      {/* Header */}
      <div style={{ position: 'relative', padding: '8px 16px 12px', display: 'flex', alignItems: 'center', gap: 8 }}>
        <button style={{ background: 'rgba(20,34,51,0.85)', border: `0.5px solid ${t.cardEdge}`, padding: 8, borderRadius: 99, cursor: 'pointer', backdropFilter: 'blur(10px)' }}>
          {Icon.chevL(t.text, 14)}
        </button>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px',
          background: 'rgba(20,34,51,0.85)', border: `0.5px solid ${t.cardEdge}`, borderRadius: 99, backdropFilter: 'blur(10px)' }}>
          {Icon.search(t.text3, 14)}
          <div style={{ fontSize: 13, color: t.text3 }}>Search a place or coordinates</div>
        </div>
      </div>
      {/* Pin label callout */}
      <div style={{ position: 'absolute', top: 305, left: 110, padding: '6px 10px',
        background: t.card, border: `0.5px solid ${t.accent}55`, borderRadius: 10,
        boxShadow: '0 4px 16px rgba(0,0,0,0.4)', fontSize: 11, fontWeight: 600, color: t.text }}>
        New spot
        <div style={{ position: 'absolute', bottom: -5, left: 24, width: 8, height: 8, background: t.card, borderRight: `0.5px solid ${t.accent}55`, borderBottom: `0.5px solid ${t.accent}55`, transform: 'rotate(45deg)' }} />
      </div>
      {/* Bottom sheet */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
        background: t.surface, borderTopLeftRadius: 22, borderTopRightRadius: 22,
        padding: '10px 18px 32px',
        boxShadow: '0 -8px 30px rgba(0,0,0,0.4)',
        border: `0.5px solid ${t.cardEdge}`,
      }}>
        <div style={{ width: 36, height: 4, background: t.text3, opacity: 0.4, borderRadius: 2, margin: '4px auto 14px' }} />
        <div style={{ fontSize: 18, fontWeight: 700, color: t.text, letterSpacing: -0.3 }}>Drop a pin</div>
        <div style={{ fontSize: 11.5, color: t.text2, marginBottom: 14 }}>
          Drag the map to position · Nearest NOAA station: <span style={{ color: t.text }}>Montauk · 2.3 mi</span>
        </div>
        {/* Name field */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: t.text3, letterSpacing: 1.4, textTransform: 'uppercase', marginBottom: 4 }}>Name</div>
          <div style={{ background: t.card, border: `0.5px solid ${t.cardEdge}`, borderRadius: 10,
            padding: '10px 12px', fontSize: 14, color: t.text, fontWeight: 600 }}>
            Montauk Point<span style={{ color: t.accent, marginLeft: 1, animation: 'blink 1s infinite' }}>|</span>
          </div>
        </div>
        {/* Type */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: t.text3, letterSpacing: 1.4, textTransform: 'uppercase', marginBottom: 4 }}>Type</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, padding: 3, background: t.card, borderRadius: 10, border: `0.5px solid ${t.cardEdge}` }}>
            <div style={{ padding: '8px 10px', borderRadius: 7, background: `${t.accent}22`, border: `0.5px solid ${t.accent}66`, fontSize: 12, fontWeight: 700, color: t.accent, textAlign: 'center' }}>
              Saltwater
            </div>
            <div style={{ padding: '8px 10px', borderRadius: 7, fontSize: 12, fontWeight: 600, color: t.text3, textAlign: 'center' }}>
              Freshwater
            </div>
          </div>
        </div>
        <button style={{
          width: '100%', padding: '12px', borderRadius: 11, border: 0,
          background: t.accent, color: '#04221C', fontWeight: 700, fontSize: 14, cursor: 'pointer',
          boxShadow: `0 4px 14px ${t.accent}55`,
        }}>Save spot</button>
      </div>
    </div>
  );
}

// ── SPECIES DETAIL ───────────────────────────────────────────────────
function SpeciesDetail({ t, sp, conditions }) {
  const col = scoreColor(sp.score, t);
  return (
    <div style={{ background: t.bgGrad, color: t.text, minHeight: '100%', paddingBottom: 30 }}>
      {/* Hero */}
      <div style={{ padding: '6px 16px 10px', display: 'flex', alignItems: 'center', gap: 8 }}>
        <button style={{ background: 'rgba(255,255,255,0.06)', border: 0, padding: 7, borderRadius: 99, cursor: 'pointer' }}>
          {Icon.chevL(t.text, 14)}
        </button>
        <div style={{ flex: 1 }} />
      </div>
      <div style={{ padding: '0 18px 16px', display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ width: 72, height: 72, borderRadius: 18, background: `linear-gradient(135deg, ${col}33, ${col}11)`,
          border: `0.5px solid ${col}55`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <FishGlyph color={col} size={48} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 22, fontWeight: 700, color: t.text, letterSpacing: -0.4, lineHeight: 1.1 }}>{sp.name}</div>
          <div style={{ fontSize: 11, fontStyle: 'italic', color: t.text2, marginTop: 1 }}>Morone saxatilis</div>
          <div style={{ marginTop: 6, display: 'inline-flex', alignItems: 'center', gap: 5, padding: '2px 8px', borderRadius: 99,
            background: `${t.green}22`, border: `0.5px solid ${t.green}44` }}>
            <div style={{ width: 5, height: 5, borderRadius: 99, background: t.green }} />
            <div style={{ fontSize: 10, fontWeight: 700, color: t.green, letterSpacing: 0.5 }}>{sp.status}</div>
          </div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 32, fontWeight: 700, color: col, lineHeight: 1, ...TAB,
            fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>{sp.score}</div>
          <div style={{ fontSize: 9, color: t.text3, fontWeight: 600, letterSpacing: 1, marginTop: 2 }}>SCORE</div>
        </div>
      </div>
      {/* Activity calendar */}
      <div style={{ padding: '0 18px 14px' }}>
        <SectionHeader t={t} title="Seasonal Activity" right="May · peak" />
        <Card t={t} padding={12}>
          <SpeciesActivityBar months={sp.months} peakMonths={sp.peakMonths} currentMonth={5} t={t} />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, fontSize: 10, color: t.text3 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <div style={{ width: 9, height: 9, background: t.green, borderRadius: 2 }} /> Peak
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <div style={{ width: 9, height: 9, background: `${t.green}55`, borderRadius: 2 }} /> Present
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <div style={{ width: 9, height: 9, border: `1.5px solid ${t.accent}`, borderRadius: 2 }} /> Now
            </div>
          </div>
        </Card>
      </div>
      {/* Match breakdown */}
      <div style={{ padding: '0 18px 14px' }}>
        <SectionHeader t={t} title="Why score 88?" />
        <Card t={t} padding={0}>
          {[
            { label: 'Month', val: '40 / 40', detail: 'Peak month — May', color: t.green },
            { label: 'Water Temp', val: '28 / 30', detail: sp.waterTempMatch, color: t.green },
            { label: 'Tide', val: '13 / 15', detail: sp.tideMatch, color: t.green },
            { label: 'Time of Day', val: '7 / 15', detail: sp.timeMatch, color: t.amber },
          ].map((r, i, arr) => (
            <div key={r.label} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px',
              borderBottom: i < arr.length - 1 ? `0.5px solid ${t.cardEdge}` : 'none',
            }}>
              <div style={{ width: 4, height: 28, background: r.color, borderRadius: 2 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: t.text }}>{r.label}</div>
                <div style={{ fontSize: 10.5, color: t.text2, marginTop: 1 }}>{r.detail}</div>
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, color: r.color, ...TAB,
                fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' }}>{r.val}</div>
            </div>
          ))}
        </Card>
      </div>
      {/* Preferred conditions */}
      <div style={{ padding: '0 18px 14px' }}>
        <SectionHeader t={t} title="Preferred Conditions" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
          <Card t={t}>
            <div style={{ fontSize: 9, color: t.text3, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Water Temp</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: t.text, ...TAB, marginTop: 2 }}>55–65°F <span style={{ color: t.text3, fontSize: 10, fontWeight: 500 }}>peak</span></div>
            <div style={{ fontSize: 10.5, color: t.text2 }}>Tolerates 50–72°F</div>
          </Card>
          <Card t={t}>
            <div style={{ fontSize: 9, color: t.text3, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Tide</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: t.text, marginTop: 2 }}>Incoming</div>
            <div style={{ fontSize: 10.5, color: t.text2 }}>Last 2 hrs of flood</div>
          </Card>
          <Card t={t}>
            <div style={{ fontSize: 9, color: t.text3, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Time</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: t.text, marginTop: 2 }}>Dawn · Dusk · Night</div>
            <div style={{ fontSize: 10.5, color: t.text2 }}>Low-light feeders</div>
          </Card>
          <Card t={t}>
            <div style={{ fontSize: 9, color: t.text3, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Structure</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: t.text, marginTop: 2 }}>Rocky points</div>
            <div style={{ fontSize: 10.5, color: t.text2 }}>Jetties, inlets, river mouths</div>
          </Card>
        </div>
      </div>
      {/* Tip card */}
      <div style={{ padding: '0 18px 16px' }}>
        <div style={{
          background: `linear-gradient(135deg, ${t.accent}22 0%, ${t.accent}08 100%)`,
          border: `0.5px solid ${t.accent}55`, borderRadius: 14,
          padding: '12px 14px', display: 'flex', gap: 10, alignItems: 'flex-start',
        }}>
          <div style={{ fontSize: 18 }}>💡</div>
          <div>
            <div style={{ fontSize: 9, color: t.accent, fontWeight: 700, letterSpacing: 1.2, textTransform: 'uppercase' }}>Today's Tip</div>
            <div style={{ fontSize: 12.5, color: t.text, marginTop: 3, lineHeight: 1.4 }}>{sp.tip}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── SETTINGS ─────────────────────────────────────────────────────────
function Settings({ t }) {
  const Row = ({ label, value, tail = 'chev', last }) => (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px',
      borderBottom: last ? 'none' : `0.5px solid ${t.cardEdge}`,
    }}>
      <div style={{ flex: 1, fontSize: 13, color: t.text }}>{label}</div>
      {value && <div style={{ fontSize: 12, color: t.text2, ...TAB }}>{value}</div>}
      {tail === 'chev' && Icon.chevR(t.text3, 12)}
      {tail === 'toggle' && (
        <div style={{ width: 32, height: 19, borderRadius: 99, background: t.green, position: 'relative' }}>
          <div style={{ position: 'absolute', top: 2, right: 2, width: 15, height: 15, borderRadius: 99, background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.4)' }} />
        </div>
      )}
      {tail === 'toggleOff' && (
        <div style={{ width: 32, height: 19, borderRadius: 99, background: 'rgba(255,255,255,0.15)', position: 'relative' }}>
          <div style={{ position: 'absolute', top: 2, left: 2, width: 15, height: 15, borderRadius: 99, background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.4)' }} />
        </div>
      )}
    </div>
  );
  const Group = ({ title, children }) => (
    <div style={{ marginBottom: 16 }}>
      <SectionHeader t={t} title={title} />
      <Card t={t} padding={0}>{children}</Card>
    </div>
  );
  return (
    <div style={{ background: t.bgGrad, color: t.text, minHeight: '100%', paddingBottom: 90 }}>
      <div style={{ padding: '8px 18px 14px' }}>
        <div style={{ fontSize: 28, fontWeight: 700, color: t.text, letterSpacing: -0.6 }}>Settings</div>
      </div>
      {/* Pro card */}
      <div style={{ padding: '0 16px 16px' }}>
        <div style={{
          padding: '14px 16px',
          background: `linear-gradient(135deg, ${t.accent}33 0%, ${t.blue}22 100%)`,
          border: `0.5px solid ${t.accent}55`, borderRadius: 16,
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: t.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#04221C', fontWeight: 700, fontSize: 14, letterSpacing: 0.5 }}>PRO</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: t.text }}>FishCast Pro</div>
            <div style={{ fontSize: 11, color: t.text2 }}>Unlimited spots · 7-day forecast · alerts</div>
          </div>
          <div style={{ fontSize: 13, fontWeight: 700, color: t.accent, ...TAB }}>$2.99/mo</div>
        </div>
      </div>
      <div style={{ padding: '0 14px' }}>
        <Group title="Alerts">
          <Row label="Push notifications" tail="toggle" />
          <Row label="Score threshold" value="≥ 75" />
          <Row label="Quiet hours" value="10p — 5a" last />
        </Group>
        <Group title="Units">
          <Row label="Temperature" value="°F" />
          <Row label="Wind" value="mph" />
          <Row label="Tide / Swell" value="ft" last />
        </Group>
        <Group title="Account">
          <Row label="Manage subscription" />
          <Row label="Restore purchases" />
          <Row label="iCloud sync" tail="toggleOff" last />
        </Group>
        <Group title="About">
          <Row label="Help & support" />
          <Row label="Privacy" />
          <Row label="Terms" last />
        </Group>
      </div>
      <div style={{ textAlign: 'center', padding: '8px 0 24px', fontSize: 10, color: t.text3, ...TAB }}>
        FishCast v1.0 (build 142)
      </div>
    </div>
  );
}

Object.assign(window, {
  ScreenHeader, DashboardComfy, DashboardRegular, DashboardCompact,
  SpotsList, AddSpot, SpeciesDetail, Settings, FishGlyph,
});
