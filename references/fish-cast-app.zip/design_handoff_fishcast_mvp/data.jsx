// data.jsx — mock data for FishCast (matches the spec)

const MOCK_SPOT = {
  id: 'spot_1', name: 'Montauk Point', region: 'Long Island, NY',
  lat: 41.0712, lng: -71.8573, type: 'saltwater',
};

const MOCK_SPOTS = [
  { id: 'spot_1', name: 'Montauk Point', region: 'Long Island, NY', score: 82, type: 'saltwater', water: 62, wind: 8, dir: 'SW', tide: 'Rising', distance: '0 mi' },
  { id: 'spot_2', name: 'Race Point Jetty', region: 'Cape Cod, MA', score: 71, type: 'saltwater', water: 58, wind: 12, dir: 'NNE', tide: 'Falling', distance: '124 mi' },
  { id: 'spot_3', name: 'Candlewood Lake', region: 'Brookfield, CT', score: 64, type: 'freshwater', water: 67, wind: 5, dir: 'W', tide: '—', distance: '88 mi' },
  { id: 'spot_4', name: 'Shinnecock Inlet', region: 'Hampton Bays, NY', score: 58, type: 'saltwater', water: 63, wind: 15, dir: 'S', tide: 'Slack', distance: '32 mi' },
  { id: 'spot_5', name: 'Block Island Sound', region: 'Block Island, RI', score: 38, type: 'saltwater', water: 60, wind: 24, dir: 'NW', tide: 'Falling', distance: '67 mi' },
];

const MOCK_CONDITIONS = {
  fishingScore: 82,
  scoreLabel: 'Great day to fish',
  bestWindow: { start: '2:00 PM', end: '5:00 PM', score: 91 },
  wind: { speed: 8, gusts: 14, direction: 225, directionLabel: 'SW', unit: 'mph' },
  tide: {
    current: { height: 3.2, rising: true, unit: 'ft' },
    next: { type: 'high', time: '3:42 PM', height: 5.1 },
    events: [
      { type: 'low',  time: '9:18 AM',  height: 0.3 },
      { type: 'high', time: '3:42 PM',  height: 5.1 },
      { type: 'low',  time: '9:55 PM',  height: 0.8 },
      { type: 'high', time: '4:12 AM',  height: 4.6 },
    ],
    hourlyCurve: [0.8, 0.5, 0.3, 0.5, 1.1, 1.9, 2.8, 3.6, 4.3, 4.8, 5.0, 5.1,
                  4.9, 4.5, 3.8, 3.0, 2.2, 1.5, 1.0, 0.8, 0.9, 1.3, 1.9, 2.7],
  },
  water: { temp: 62, unit: '°F' },
  air: { temp: 68, high: 72, low: 58, humidity: 74, unit: '°F' },
  pressure: { value: 30.02, trend: 'falling', unit: 'inHg' },
  swell: { height: 3.2, period: 8, direction: 180, directionLabel: 'S', unit: 'ft' },
  sky: { condition: 'Partly Cloudy', rain_chance: 20 },
  sun: { sunrise: '5:42 AM', sunset: '8:12 PM' },
  moon: {
    phase: 'Waxing Gibbous', illumination: 78,
    majorPeriods: [{ start: '2:15 PM', end: '4:15 PM' }, { start: '2:45 AM', end: '4:45 AM' }],
    minorPeriods: [{ start: '8:30 AM', end: '9:30 AM' }, { start: '9:00 PM', end: '10:00 PM' }],
  },
  hourlyScores: [
    { hour: '5A', score: 65 }, { hour: '6A', score: 72 }, { hour: '7A', score: 68 },
    { hour: '8A', score: 55 }, { hour: '9A', score: 48 }, { hour: '10', score: 42 },
    { hour: '11', score: 38 }, { hour: '12', score: 45 }, { hour: '1P', score: 58 },
    { hour: '2P', score: 78 }, { hour: '3P', score: 91 }, { hour: '4P', score: 88 },
    { hour: '5P', score: 82 }, { hour: '6P', score: 75 }, { hour: '7P', score: 70 },
    { hour: '8P', score: 62 },
  ],
};

const MOCK_SPECIES = [
  { name: 'Striped Bass', score: 88, status: 'Peak Season',
    waterTempMatch: 'In range (62°F — ideal 55–65°F)',
    tideMatch: 'Incoming — preferred',
    timeMatch: 'Approaching dusk — prime time',
    tip: 'Try topwater near rocky points on the incoming tide.',
    range: { min: 50, max: 72, peakMin: 55, peakMax: 65 },
    months: [4,5,6,7,8,9,10,11], peakMonths: [5,6,9,10],
  },
  { name: 'Bluefish', score: 74, status: 'Active',
    waterTempMatch: 'In range (62°F — ideal 60–72°F)',
    tideMatch: 'Incoming — good',
    timeMatch: 'Midday — secondary',
    tip: 'Look for surface blitzes near bait schools.',
    range: { min: 55, max: 78, peakMin: 60, peakMax: 72 },
    months: [5,6,7,8,9,10], peakMonths: [6,7,9],
  },
  { name: 'Fluke', score: 51, status: 'Present',
    waterTempMatch: 'Slightly cool (62°F — ideal 66–74°F)',
    tideMatch: 'Incoming — neutral for fluke',
    timeMatch: 'Afternoon — okay',
    tip: 'Drift bucktails along sandy bottom near channel edges.',
    range: { min: 55, max: 80, peakMin: 66, peakMax: 74 },
    months: [5,6,7,8,9], peakMonths: [6,7,8],
  },
];

// Recompute hourly scores into time-of-day skewed shapes
function shapeForTimeOfDay(tod) {
  // base curve from spec, peak at 3pm; we shift the peak.
  const base = MOCK_CONDITIONS.hourlyScores.map(h => h.score);
  const shift = tod === 'dawn' ? -7 : tod === 'midday' ? -3 : tod === 'dusk' ? 1 : 0;
  // Instead, reshape: dawn → peak at hour 1-2; midday → peak at hour 7; dusk → peak at hour 11
  const peak = tod === 'dawn' ? 1 : tod === 'midday' ? 7 : 10;
  const out = base.map((_, i) => {
    const d = Math.abs(i - peak);
    const v = 95 - d * 6 - (i % 3 === 0 ? 4 : 0);
    return Math.max(20, Math.min(95, Math.round(v)));
  });
  return MOCK_CONDITIONS.hourlyScores.map((h, i) => ({ hour: h.hour, score: out[i] }));
}

Object.assign(window, { MOCK_SPOT, MOCK_SPOTS, MOCK_CONDITIONS, MOCK_SPECIES, shapeForTimeOfDay });
